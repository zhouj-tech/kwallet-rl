#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────
# run_stage2b_mac.sh — ONE-COMMAND PI execution for complete Stage 2B batch
# on Mac (CPU-only, no MPS, no retraining, no PR #3).
#
# Provenance:
#   MAC_RUNTIME_APPROVED — 2026-10-02, all 5 evaluator families (JA-PPO, IFAC,
#   SC-FAC, SC-FAC-zero, BF-T0.5) achieved exact SHA256 parity with Linux server
#   reference runs. All 42 evaluation jobs in STAGE2_JOB_MATRIX.csv.
#
# Prerequisites:
#   1. Bundle extracted: this script lives at bundle root alongside run_benchmark.py
#      and stage2b_orchestrator.py
#   2. Python 3.10+ venv with matching versions (see MAC_RUNTIME_APPROVED.json)
#   3. macOS with caffeinate (bult-in), tmux (brew install tmux)
#
# What it does:
#   1. Verify venv, SHA integrity of frozen artifacts, and receipt
#   2. Start caffeinate to prevent Mac sleep during execution
#   3. Launch stage2b_orchestrator.py in a tmux session (session name: aamas_mac_stage2b)
#   4. Orchestrator reads STAGE2_JOB_MATRIX.csv, runs all 42 eval jobs sequentially,
#      maintains output/progress_ledger.json, handles resume/skip/retry,
#      stops on scientific failure, permits safe retry on infrastructure failure
#   5. Exit: 0 = all 42 PASS, 1 = partial/skip, 2 = scientific fail, 3 = infra fail
#
# One command:
#   cd A-EVAL-JA-C800-S123 && ./run_stage2b_mac.sh
#
# ──────────────────────────────────────────────────────────────────────────
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BUNDLE_DIR"

# ── 0. Banner ─────────────────────────────────────────────────────────────
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║  AAMAS 2027 — STAGE 2B MAC CPU EXECUTION                                  ║"
echo "║  MAC_RUNTIME_APPROVED — 2026-10-02                                        ║"
echo "║  42 evaluation jobs, 5 families, single Mac CPU runtime                   ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""

# ── 1. Verify prerequisites ────────────────────────────────────────────────
echo "[1/6] Verifying prerequisites..."

# MAC_RUNTIME_APPROVED.json
RECEIPT="$BUNDLE_DIR/MAC_RUNTIME_APPROVED.json"
if [ ! -f "$RECEIPT" ]; then
    echo "  ❌ MAC_RUNTIME_APPROVED.json NOT FOUND at $RECEIPT"
    exit 1
fi
echo "  ✅ MAC_RUNTIME_APPROVED.json present"

# tmux
if ! command -v tmux &>/dev/null; then
    echo "  ❌ tmux not found. Install with: brew install tmux"
    exit 1
fi
echo "  ✅ tmux available"

# caffeinate (macOS-only check)
if ! command -v caffeinate &>/dev/null; then
    echo "  ❌ caffeinate not found (macOS built-in). Are you running on Mac?"
    exit 1
fi
echo "  ✅ caffeinate available"

# Python
PYTHON="${PYTHON:-python3}"
if ! command -v "$PYTHON" &>/dev/null; then
    echo "  ❌ python3 not found. Activate your venv first."
    exit 1
fi
PY_VERSION=$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")')
echo "  ✅ Python $PY_VERSION  ($PYTHON)"

# Verify frozen SHAs — all sourced from MAC_RUNTIME_APPROVED.json (single source of truth)
echo ""
echo "[2/6] Verifying frozen artifact integrity..."
"$PYTHON" -c "
import hashlib, sys, json
from pathlib import Path
bundle = Path('$BUNDLE_DIR')
rcpt = json.loads(Path('$RECEIPT').read_text())

# Define {relpath: receipt_field} — all expected SHAs come from receipt
checks = [
    ('run_benchmark.py',                    'run_benchmark_sha256'),
    ('stage2b_orchestrator.py',             'orchestrator_sha256'),
    ('run_stage2b_mac.sh',                  'shell_launcher_sha256'),
    ('code/kwallet-rl_H5573ec64.tar.gz',     'repo_tar_sha256'),
    ('data/research/STAGE2_JOB_MATRIX.csv',  'job_matrix_sha256'),
    ('data/research/AAMAS_ARTIFACT_MANIFEST.csv', 'artifact_manifest_sha256'),
    ('data/streams/NEW12-v1/new12_manifest.json', 'new12_manifest_sha256'),
    ('data/streams/NEW12-v1/overlap_report.json', 'overlap_report_sha256'),
    ('data/streams/NEW12-v1/freeze_receipt.json', 'freeze_receipt_sha256'),
    ('data/g3/g3_receipt.json',              'g3_receipt_sha256'),
]
all_ok = True
for rel, field in checks:
    expected = rcpt.get(field)
    p = bundle / rel
    if not p.is_file():
        print(f'  ❌ MISSING: {rel}')
        all_ok = False; continue
    actual = hashlib.sha256(p.read_bytes()).hexdigest()
    if actual != expected:
        print(f'  ❌ SHA MISMATCH: {rel}')
        print(f'     expected: {expected}')
        print(f'     actual:   {actual}')
        all_ok = False
    else:
        print(f'  ✅ {rel}  (SHA {actual[:16]}…)')

# Verify receipt integrity (adapter.py SHA verified by run_benchmark.py → verify_sources)
print(f'  receipt.approval_status: {rcpt.get(\"approval_status\")}')
print(f'  receipt.git_head:        {rcpt.get(\"git_head\")}')
print(f'  receipt.cpu_only:        {rcpt.get(\"cpu_only\")}')
print(f'  receipt.exact_parity:    {rcpt.get(\"exact_parity_confirmed\")}')

if not all_ok:
    print()
    print('  ❌ Integrity check FAILED. Bundle may be corrupted or modified.')
    sys.exit(1)
"

# ── 3. Activate venv if not already ─────────────────────────────────────────
echo ""
echo "[3/6] Environment check..."
if [ -n "${VIRTUAL_ENV:-}" ]; then
    echo "  venv already active: $VIRTUAL_ENV"
else
    if [ -f ".venv-kwallet/bin/activate" ]; then
        source .venv-kwallet/bin/activate
        echo "  Activated: .venv-kwallet"
    elif [ -f "venv/bin/activate" ]; then
        source venv/bin/activate
        echo "  Activated: venv"
    else
        echo "  ⚠️  No venv detected. Activate your matching Python 3.10+ venv with:"
        echo "     pip install 'numpy==2.0.2' 'torch==2.5.1+cpu' --index-url https://download.pytorch.org/whl/cpu"
    fi
fi

"$PYTHON" -c "
import numpy, torch, platform
print(f'  NumPy {numpy.__version__}  Torch {torch.__version__}')
print(f'  Platform: {platform.system()} {platform.machine()}')
print(f'  Torch threads: {torch.get_num_threads()}')
assert 'cpu' not in torch.__version__ or 'cu118' not in torch.__version__, 'Should use CPU wheel on Mac'
assert platform.system() == 'Darwin', 'This bundle is for Mac (Darwin)'
print('  ✅ Environment OK')
"

# ── 4. Show execution plan ──────────────────────────────────────────────────
echo ""
echo "[4/6] Execution plan..."
"$PYTHON" stage2b_orchestrator.py --list-only

# ── 5. Launch tmux + caffeinate ──────────────────────────────────────────────
echo ""
echo "[5/6] Launching Mac runtime..."
SESSION="aamas_mac_stage2b"
LOG_FILE="$BUNDLE_DIR/output/stage2b_full.log"
mkdir -p "$BUNDLE_DIR/output" "$BUNDLE_DIR/output/_logs"

# Kill existing session
if tmux has-session -t "$SESSION" 2>/dev/null; then
    echo "  Existing tmux session '$SESSION' found — killing (will resume from ledger)"
    tmux kill-session -t "$SESSION"
fi

echo "  tmux session:   $SESSION"
echo "  caffeinate:      yes (prevent sleep during evaluation)"
echo "  log file:        $LOG_FILE"
echo "  commands:        tmux attach -t $SESSION"
echo "                   tail -f $LOG_FILE"
echo ""
echo "  Launching orchestrator..."
echo "  ────────────────────────────────────────────────────────────────────"

tmux new-session -d -s "$SESSION" "cd '$BUNDLE_DIR' && caffeinate -dimsu '$PYTHON' stage2b_orchestrator.py 2>&1 | tee '$LOG_FILE'"

echo "  ✅ Orchestrator launched in tmux session '$SESSION'"
echo ""

# ── 6. Status poll ──────────────────────────────────────────────────────────
echo "[6/6] Initial status poll..."
sleep 8

if [ -f "$LOG_FILE" ]; then
    echo ""
    echo "  ┌─ Initial output ──────────────────────────────────────────────"
    tail -30 "$LOG_FILE" | sed 's/^/  │  /'
    echo "  └──────────────────────────────────────────────────────────────┘"
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║  LAUNCH COMPLETE                                                          ║"
echo "║                                                                            ║"
echo "║  Monitor:  tmux attach -t $SESSION                                   ║"
echo "║  Or tail:  tail -f $LOG_FILE"
echo "║  Ledger:   output/progress_ledger.json  (machine-readable JSON)         ║"
echo "║  Per-job:  output/_logs/<job_id>.log                                      ║"
echo "║  Complete: output/<job_id>/{episodes.csv,result.json,diagnostics.json}   ║"
echo "║                                                                            ║"
echo "║  Resume:    Run this script again — validly completed jobs will skip.     ║"
echo "║  Safely cancel: tmux kill-session -t $SESSION                            ║"
echo "║  Retry infra: ./run_stage2b_mac.sh  (ledger tracks infra failures)        ║"
echo "║                                                                            ║"
echo "║  Exit codes: 0 = all PASS  2 = scientific fail  3 = infra fail           ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
