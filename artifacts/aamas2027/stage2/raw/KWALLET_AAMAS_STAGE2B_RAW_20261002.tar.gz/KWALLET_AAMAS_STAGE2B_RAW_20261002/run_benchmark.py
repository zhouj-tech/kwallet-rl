#!/usr/bin/env python3
"""
run_benchmark.py — Local-CPU parity benchmark for ALL Stage 2B evaluator families.

Core call chain (identical to adapter.execute(), skipping host-specific gates):
  adapter.verify_sources    ← FROZEN adapter
  [SKIP verify_runtime / verify_new_release]
  resolve_artifacts()       ← BENCHMARK-ONLY: handles direct / receipt / BF-T0.5
  adapter.check_config      ← FROZEN adapter gate
  adapter.import_original   ← FROZEN adapter
  adapter.output_bundle     ← FROZEN adapter (does 12×200 policy evaluations)

Supports ALL evaluator families from STAGE2_JOB_MATRIX:
  JA-PPO, IFAC, SC-FAC, SC-FAC-zero, BF-T0.5

Usage:
  python run_benchmark.py --job-id A-EVAL-IF-C800-S123
  python run_benchmark.py --job-id A-EVAL-SC-C800-S123
  python run_benchmark.py --job-id B-EVAL-ZERO-C800-S123
  python run_benchmark.py --job-id C-EVAL-BFT05-C800
  python run_benchmark.py --all-validation       # all 4 family reps sequentially

Outputs written to <benchmark-dir>/output/<job_id>/ — NEVER official evaluations/.

BENCHMARK ONLY — not an official Stage 2 scientific output unless a later
PI-approved local-runtime parity gate passes.
"""
import argparse, csv, hashlib, io, json, os, shutil, sys, time, tarfile
from pathlib import Path
import numpy as np

BUNDLE_ROOT = Path(__file__).resolve().parent
REPO_TAR    = BUNDLE_ROOT/'code'/'kwallet-rl_H5573ec64.tar.gz'
REPO_DIR    = BUNDLE_ROOT/'repo_unpacked'
DATA_DIR    = BUNDLE_ROOT/'data'
STREAMS_DIR = DATA_DIR/'streams'/'NEW12-v1'
MANIFEST_CSV = DATA_DIR/'research'/'AAMAS_ARTIFACT_MANIFEST.csv'
JOB_MATRIX   = DATA_DIR/'research'/'STAGE2_JOB_MATRIX.csv'
VALIDATION_JOBS = ['A-EVAL-IF-C800-S123', 'A-EVAL-SC-C800-S123',
                   'B-EVAL-ZERO-C800-S123', 'C-EVAL-BFT05-C800']

def sha256(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

# ---------------------------------------------------------------------------
# Step 1: Unpack repo tarball + import frozen adapter
# ---------------------------------------------------------------------------
if REPO_DIR.exists(): shutil.rmtree(REPO_DIR)
REPO_DIR.mkdir()
with tarfile.open(REPO_TAR, 'r:gz') as tf: tf.extractall(REPO_DIR)
print(f"[benchmark] Repo unpacked to {REPO_DIR}")

adapter_py = next((c for c in REPO_DIR.rglob('adapter.py') if 'aamas_stage2' in str(c)), None)
assert adapter_py, "adapter.py not found"
REPO = adapter_py.parent.parent.parent.resolve()
sys.path.insert(0, str(REPO/'tools'/'aamas_stage2'))
import adapter  # noqa: E402
print(f"[benchmark] Repo root: {REPO}")
print(f"[benchmark] adapter.py SHA: {sha256(adapter_py)}  (frozen)")

# ---------------------------------------------------------------------------
# adapter.output_bundle calls adapter.git_state(args.repo) which does
# `git -C REPO rev-parse HEAD`. Our REPO is extracted from git archive — no
# .git dir exists. Benchmark-only fix: monkey-patch git_state to return the
# known frozen HEAD (deterministic, no persistent repo mutation).
# ---------------------------------------------------------------------------
_FROZEN_GIT = {'git_sha': '5573ec642f0f28c218f3e6058478f62ab6db6b2b',
               'git_status': '',
               'tracked_diff_sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}
adapter.git_state = lambda _repo: dict(_FROZEN_GIT)
print(f"[benchmark] adapter.git_state monkey-patched → frozen HEAD 5573ec64…b6b2b")

# Step 2: env
os.environ['XDG_CACHE_HOME'] = str((BUNDLE_ROOT/'_xdg_cache').resolve())
os.environ['MPLCONFIGDIR']   = str((BUNDLE_ROOT/'_mpl_cache').resolve())
os.makedirs(os.environ['XDG_CACHE_HOME'], exist_ok=True)
os.makedirs(os.environ['MPLCONFIGDIR'], exist_ok=True)

# ---------------------------------------------------------------------------
# Step 3: Artifact resolution — replaces adapter.resolve_model (which needs
#         a fully populated artifact_inventory we intentionally don't ship).
# ---------------------------------------------------------------------------
def resolve_artifacts(job, adapter_mod):
    """Dispatch to correct resolver based on job method + checkpoint_source."""
    method = job['method']
    cp_src = job['checkpoint_source']

    if method == 'BF-T0.5':
        return _resolve_bf_t05(job, adapter_mod)
    if cp_src.startswith('receipt:'):
        return _resolve_receipt(job, adapter_mod)
    return _resolve_direct(job, adapter_mod)

def _resolve_direct(job, adapter_mod):
    """Direct checkpoint path (JA-PPO, IFAC, SC-FAC, SC-FAC-zero direct)."""
    method = job['method']
    C = job['C']
    seed = job['seed']

    # Remap server absolute path → bundle-relative path
    # Server: /data/sijia/aamas2027_artifacts/checkpoints/basic_ppo/basic_ppo_trainMIX12_EQ_C800_k24_T1000_F3_seed123/20260508_222529_095916/best_model.pth
    # Bundle: data/checkpoints/{METHOD}_C{C}_S{seed}_best_model.pth
    cp_bundle_name = f"{method}_C{C}_S{seed}_best_model.pth"
    ri_bundle_name = f"{method}_C{C}_S{seed}_run_info.json"
    # For JA-PPO backward compat: also check the original names
    candidates_cp = [DATA_DIR/'checkpoints'/cp_bundle_name,
                     DATA_DIR/'checkpoints'/'best_model.pth']
    candidates_ri = [DATA_DIR/'metadata'/ri_bundle_name,
                     DATA_DIR/'metadata'/'run_info.json']

    cp = next((c for c in candidates_cp if c.is_file()), None)
    ri = next((c for c in candidates_ri if c.is_file()), None)
    adapter_mod.require(cp is not None,
                        f'Missing checkpoint for {job["job_id"]}: tried {[str(c) for c in candidates_cp]}')
    adapter_mod.require(ri is not None,
                        f'Missing run_info for {job["job_id"]}: tried {[str(c) for c in candidates_ri]}')

    # Verify SHA from job matrix (trusted frozen value)
    cp_sha_expected = job['checkpoint_sha256']
    adapter_mod.require(cp_sha_expected != 'NOT_APPLICABLE_RULE',
                        f'checkpoint_sha256 column says N/A for direct-path job')
    cp_sha = sha256(cp)
    info_sha = sha256(ri)
    adapter_mod.require(cp_sha == cp_sha_expected,
                        f'CP SHA mismatch for {job["job_id"]}: got {cp_sha}  !=  expected {cp_sha_expected}')

    cfg = json.loads(ri.read_text())['config']
    adapter_mod.check_config(cfg, job)
    print(f"[3/4] Direct artifact load → {method}")
    print(f"       cp={cp.name}  sha={cp_sha[:16]}…")
    print(f"       ri={ri.name}  sha={info_sha[:16]}…")
    print(f"       cfg: model_mode={cfg.get('model_mode')} env.C={cfg['env']['C']} k={cfg['env']['k']} "
          f"F={cfg['env']['F']} T={cfg['env']['T']} seed={cfg['seed']}")
    if method.startswith('SC-FAC'):
        print(f"       condition_mode: {cfg.get('condition_mode','full')}  (job: {job['condition_mode']})")
    return cfg, cp, cp_sha, info_sha

def _resolve_bf_t05(job, adapter_mod):
    """BF-T0.5 rule-based evaluation — cp=None, uses JA-PPO transfer config."""
    C = job['C']
    # Transfer config comes from JA-PPO C={C} seed=123 run_info
    transfer = DATA_DIR/'metadata'/f"jappo_C{C}_S123_run_info.json"
    adapter_mod.require(transfer.is_file(),
                        f'Missing JA-PPO transfer run_info for BF-T0.5 C={C}: {transfer}')
    transfer_sha = sha256(transfer)
    # Verify matches frozen expected
    expected = {'800': '55e0ee7782cbf5dc7653ec96f899b2125ccec39e4c720f72486083b2b3427740',
                '1200': None}  # 1200 not yet frozen-validated, but bundle has it
    exp = expected.get(str(C))
    if exp:
        adapter_mod.require(transfer_sha == exp,
                            f'BF-T0.5 C={C} transfer SHA mismatch: {transfer_sha} != {exp}')
    cfg = json.loads(transfer.read_text())['config']
    # check_config as JA-PPO (not BF-T0.5)
    adapter_mod.check_config(cfg, dict(job, method='JA-PPO', seed='123'))
    print(f"[3/4] BF-T0.5 rule-based  cp=None  transfer_ri={transfer.name}  sha={transfer_sha[:16]}…")
    print(f"       cfg: model_mode={cfg.get('model_mode')} env.C={cfg['env']['C']} k={cfg['env']['k']} "
          f"F={cfg['env']['F']} T={cfg['env']['T']}")
    return cfg, None, None, transfer_sha  # cp=None for rule eval

def _resolve_receipt(job, adapter_mod):
    """Receipt-based SC-FAC-zero (seeds 777, 999).

    Receipt is at data/training/{train_tid}/receipt.json. The cp and ri
    referenced by the receipt's absolute server paths are already copied
    into data/checkpoints/ and data/metadata/ with our naming convention —
    we load them via the same bundle-relative naming used by _resolve_direct,
    then verify cp SHA against the receipt's known frozen value.
    """
    train_tid = job['job_id'].replace('B-EVAL-', 'B-TRAIN-')
    receipt_path = DATA_DIR/'training'/train_tid/'receipt.json'
    adapter_mod.require(receipt_path.is_file(), f'Missing training receipt: {receipt_path}')
    receipt = json.loads(receipt_path.read_text())
    # Verify receipt integrity (adapter SHA frozen known value)
    _ADAPTER_SHA_FROZEN = '7a5840239ff3a398295267ae23c840f07962c50ed1fbf34a39481ed3fd864c42'
    adapter_mod.require(receipt.get('adapter_sha256') == _ADAPTER_SHA_FROZEN,
        f'Receipt adapter SHA mismatch: {receipt.get("adapter_sha256")}')
    att = receipt.get('attestations', {})
    adapter_mod.require(att.get('pr3_used') is False, f'Receipt attestation: PR #3 was used (forbidden)')
    adapter_mod.require(att.get('principal_policy_trained') is False,
        f'Receipt attestation: principal policy was retrained (forbidden)')

    # Load cp + ri via bundle-relative naming (same as direct-path)
    cp_bundle_name = f"SC-FAC-zero_C{job['C']}_S{job['seed']}_best_model.pth"
    ri_bundle_name = f"SC-FAC-zero_C{job['C']}_S{job['seed']}_run_info.json"
    cp = DATA_DIR/'checkpoints'/cp_bundle_name
    ri = DATA_DIR/'metadata'/ri_bundle_name
    adapter_mod.require(cp.is_file() and ri.is_file(),
                        f'Receipt artifact missing in bundle: {cp_bundle_name} / {ri_bundle_name}')
    cp_sha = sha256(cp); info_sha = sha256(ri)
    adapter_mod.require(cp_sha == receipt['best_checkpoint_sha256'],
                        f'Receipt CP SHA mismatch: {cp_sha} != {receipt["best_checkpoint_sha256"]}')
    cfg = json.loads(ri.read_text())['config']
    adapter_mod.check_config(cfg, job)
    print(f"[3/4] Receipt-based  train_tid={train_tid}  cp_sha={cp_sha[:16]}…  (receipt verified)")
    return cfg, cp, cp_sha, info_sha

# ---------------------------------------------------------------------------
# Step 4: Build argparse namespace
# ---------------------------------------------------------------------------
def build_args(benchmark_dir, job_id):
    ns = argparse.Namespace()
    ns.repo = REPO
    ns.artifacts = DATA_DIR
    ns.work_root = Path(benchmark_dir).resolve()
    ns.runtime_lock = None; ns.runtime_lock_sha256 = None
    ns.allow_new12 = True
    ns.new12_root = STREAMS_DIR
    ns.freeze_receipt = STREAMS_DIR/'freeze_receipt.json'
    ns.freeze_receipt_sha256 = sha256(ns.freeze_receipt)
    ns.g3_receipt = DATA_DIR/'g3'/'g3_receipt.json'
    ns.g3_receipt_sha256 = sha256(ns.g3_receipt)
    ns.jobs = JOB_MATRIX; ns.manifest = MANIFEST_CSV
    ns.plan = DATA_DIR/'research'/'STAGE2_EXECUTION_PLAN.md'
    ns.job_id = job_id
    return ns

# ---------------------------------------------------------------------------
# Step 5: Run one job
# ---------------------------------------------------------------------------
def run_one(benchmark_dir, job_id):
    bench_dir = Path(benchmark_dir).resolve()
    out_dir = bench_dir/'output'/job_id
    if out_dir.exists(): shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    args = build_args(bench_dir, job_id)
    start_time = time.time()

    print(f"\n{'='*70}")
    print(f"BENCHMARK: {job_id}")
    print(f"{'='*70}")
    print(f"Start:  {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(start_time))}")
    print(f"Output: {out_dir}")

    jobs = adapter.load_jobs(args.jobs)
    job = jobs[job_id]
    print(f"\nJob: method={job['method']} C={job['C']} seed={job['seed']} cond={job['condition_mode']}")

    # [1/4] verify_sources — FROZEN
    print(f"\n[1/4] adapter.verify_sources(repo) ... ", end='', flush=True)
    adapter.verify_sources(REPO); print("OK")

    # [2/4] NEW12 streams
    manifest = adapter.read_json(STREAMS_DIR/'new12_manifest.json', sha256(STREAMS_DIR/'new12_manifest.json'))
    print(f"[2/4] NEW12 manifest: {len(manifest['pools'])} pools, status={manifest.get('status','ok')}")
    streams = []
    for p in manifest['pools']:
        path = STREAMS_DIR/p['filename']
        pool, hashes = adapter.load_pool(path, p['sha256'], p['episode_hashes'])
        streams.append(dict(regime=p['regime'], path=str(path), sha256=p['sha256'],
                            episode_seeds=p['episode_seeds'], episode_hashes=p['episode_hashes']))
    manifest_sha = sha256(STREAMS_DIR/'new12_manifest.json')

    # [3/4] resolve_artifacts — BENCHMARK-ONLY
    cfg, cp, cp_sha, info_sha = resolve_artifacts(job, adapter)

    # [4/4] import_original — FROZEN
    module = adapter.import_original(REPO, job['method'])
    print(f"[4/4] adapter.import_original('{job['method']}') OK")

    # output_bundle — FROZEN
    print(f"\n[EVAL] adapter.output_bundle({len(streams)} streams x 200 = 2400 episodes)")
    bundle_start = time.time()
    files, raw = adapter.output_bundle(args, job, cfg, cp, cp_sha, info_sha,
                                       module, streams, 'NEW12-v1', manifest_sha)
    print(f"       OK in {time.time()-bundle_start:.1f}s")

    # Add metadata
    result_doc = json.loads(files['result.json'])
    result_doc.update(
        runtime='local_benchmark_only',
        started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(start_time)),
        completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        elapsed_seconds=time.time() - start_time,
        episodes_sha256=hashlib.sha256(files['episodes.csv'].encode()).hexdigest(),
    )
    import platform, torch  # noqa: E402
    result_doc['runtime_local'] = dict(
        platform=f"{platform.system()} {platform.release()} {platform.machine()}",
        processor=platform.processor(), python_version=platform.python_version(),
        numpy_version=np.__version__, torch_version=torch.__version__,
        torch_threads=torch.get_num_threads(),
        torch_interop_threads=torch.get_num_interop_threads(),
        nproc=os.cpu_count(),
    )
    result_doc['benchmark_note'] = (
        f'LOCAL-BENCHMARK job_id={job_id} — not official Stage 2 output. '
        f'Compare with server reference evaluations/{job_id}/ if available.'
    )
    files['result.json'] = json.dumps(result_doc, sort_keys=True, indent=2, allow_nan=False) + '\n'

    # Write
    print(f"\n[WRITE] Outputs to {out_dir}:")
    for fname, content in files.items():
        fpath = out_dir / fname
        fpath.write_text(content)
        print(f"  {fname:18s}  sha256={sha256(fpath)[:16]}…")

    # Summary
    elapsed = time.time() - start_time
    print(f"\n{'='*70}")
    print(f"COMPLETE  {job_id}  wall={elapsed:.1f}s ({elapsed/60:.2f} min)")
    print(f"{'='*70}")
    print(f"  rows:          {result_doc['row_count']}")
    print(f"  macro12_money: {result_doc['macro12_money']}")
    for reg in ['US','TLS','LNS','TLNS','TPLS','PLS','UB','TLB','LNB','TLNB','TPLB','PLB']:
        m = result_doc['regime_summaries'][reg]['eval_money']['mean']
        print(f"  {reg:5s}: {m:10.4f}")

    return result_doc, out_dir, elapsed

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Local-CPU parity benchmark (all Stage 2B families)')
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--job-id', help='Single job_id from STAGE2_JOB_MATRIX.csv')
    g.add_argument('--all-validation', action='store_true',
                   help='Run all 4 family validation representatives sequentially')
    ap.add_argument('--benchmark-dir', default=str(BUNDLE_ROOT))
    args = ap.parse_args()

    if args.all_validation:
        print(f"\n{'#'*70}")
        print(f"RUNNING ALL 4 FAMILY VALIDATION REPRESENTATIVES")
        print(f"{'#'*70}")
        summaries = {}
        for jid in VALIDATION_JOBS:
            try:
                result_doc, out_dir, elapsed = run_one(args.benchmark_dir, jid)
                summaries[jid] = {
                    'status': 'OK',
                    'macro12_money': result_doc.get('macro12_money'),
                    'row_count': result_doc.get('row_count'),
                    'wall_seconds': round(elapsed, 1),
                    'output_dir': str(out_dir),
                }
            except Exception as e:
                import traceback; traceback.print_exc()
                summaries[jid] = {'status': f'FAIL: {e}'}
        print(f"\n{'='*70}")
        print(f"VALIDATION SUMMARY (ALL 4 FAMILIES)")
        print(f"{'='*70}")
        for jid in VALIDATION_JOBS:
            s = summaries[jid]
            if s['status'] == 'OK':
                print(f"  PASS  {jid:28s}  macro={s['macro12_money']:10.2f}  rows={s['row_count']}  "
                      f"wall={s['wall_seconds']}s")
            else:
                print(f"  FAIL  {jid:28s}  {s['status']}")
    else:
        run_one(args.benchmark_dir, args.job_id)
