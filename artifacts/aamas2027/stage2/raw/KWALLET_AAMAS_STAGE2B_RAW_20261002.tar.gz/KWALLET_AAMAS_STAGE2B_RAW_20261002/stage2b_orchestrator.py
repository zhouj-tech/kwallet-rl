#!/usr/bin/env python3
"""
stage2b_orchestrator.py — Production orchestrator for the complete Stage 2B
evaluation batch on Mac (CPU-only, no MPS, no retraining, no PR #3).

Responsibilities:
  1. Read frozen STAGE2_JOB_MATRIX.csv — filter to evaluation jobs (training_required=false).
  2. Execute jobs sequentially via run_benchmark.py --job-id (separate process per job).
  3. Resume after interruption: detect already-completed valid jobs → skip them.
  4. Never silently overwrite a valid completed result.
  5. Maintain one separate output directory per job, one log per job.
  6. Verify row_count and validation_status after each job.
  7. Compute SHA256 for scientific outputs (episodes.csv, result.json).
  8. Maintain machine-readable progress ledger at output/progress_ledger.json.
  9. Record start/end timestamps and wall time.
 10. Stop on scientific validation failure.
 11. Distinguish infrastructure failure (OSError, timeout, crash) from
      scientific failure (adapter.Stop, validation_status != PASS).
 12. Permit safe retry after infrastructure failure (--retry-infra).

Usage:
  python3 stage2b_orchestrator.py [--skip-validation-reps] [--retry-infra] [--job-id X]
  python3 stage2b_orchestrator.py --list-only     # print ordered job list then exit

Execution order (frozen — defined here, NOT user-editable):
  Groups run in dependency order, seeds within each group are deterministic.
  All groups are independent except receipt-based SC-FAC-zero which depends
  on training (already complete — Stage 2A Part B).

    Group 1: BF-T0.5 (2 jobs, rule-based — no CP needed, FAST)
    Group 2: JA-PPO direct C800 (5 seeds)
    Group 3: JA-PPO direct C1200 (5 seeds)
    Group 4: IFAC direct C800 (5 seeds)
    Group 5: IFAC direct C1200 (5 seeds)
    Group 6: SC-FAC direct C800 (5 seeds)
    Group 7: SC-FAC direct C1200 (5 seeds)
    Group 8: SC-FAC-zero direct C800 seeds 123,323,532 (3 jobs)
    Group 9: SC-FAC-zero direct C1200 seeds 123,323,532 (3 jobs)
    Group 10: SC-FAC-zero receipt C800 seeds 777,999 (2 jobs)
    Group 11: SC-FAC-zero receipt C1200 seeds 777,999 (2 jobs)
    ──────────────────────────────────────────────────────────────
    Total: 42 evaluation jobs

Authoritative sources of truth (frozen — no modifications permitted):
  STAGE2_JOB_MATRIX.csv        (42 eval jobs defined here)
  adapter.py SHA:              7a5840239ff3a398295267ae23c840f07962c50ed1fbf34a39481ed3fd864c42
  Git HEAD:                    5573ec642f0f28c218f3e6058478f62ab6db6b2b
  MAC_RUNTIME_APPROVED:        confirmed (exact parity on all 5 families, 2026-10-02)
"""
import argparse, csv, hashlib, json, os, subprocess, sys, time
from pathlib import Path

BUNDLE_ROOT = Path(__file__).resolve().parent
BENCHMARK_PY = BUNDLE_ROOT/'run_benchmark.py'
JOB_MATRIX = BUNDLE_ROOT/'data'/'research'/'STAGE2_JOB_MATRIX.csv'
OUTPUT_DIR = BUNDLE_ROOT/'output'
LEDGER_PATH = OUTPUT_DIR/'progress_ledger.json'
LOG_DIR = OUTPUT_DIR/'_logs'

# Execution order — FROZEN
EXECUTION_ORDER = [
    # Group 1: BF-T0.5 rule-based (2)
    ('BF-T0.5',  'C800',  'NA', 'direct'),
    ('BF-T0.5',  'C1200', 'NA', 'direct'),
    # Group 2-3: JA-PPO direct (10)
    ('JA-PPO',   'C800',  '123', 'direct'),
    ('JA-PPO',   'C800',  '323', 'direct'),
    ('JA-PPO',   'C800',  '532', 'direct'),
    ('JA-PPO',   'C800',  '777', 'direct'),
    ('JA-PPO',   'C800',  '999', 'direct'),
    ('JA-PPO',   'C1200', '123', 'direct'),
    ('JA-PPO',   'C1200', '323', 'direct'),
    ('JA-PPO',   'C1200', '532', 'direct'),
    ('JA-PPO',   'C1200', '777', 'direct'),
    ('JA-PPO',   'C1200', '999', 'direct'),
    # Group 4-5: IFAC direct (10)
    ('IFAC',     'C800',  '123', 'direct'),
    ('IFAC',     'C800',  '323', 'direct'),
    ('IFAC',     'C800',  '532', 'direct'),
    ('IFAC',     'C800',  '777', 'direct'),
    ('IFAC',     'C800',  '999', 'direct'),
    ('IFAC',     'C1200', '123', 'direct'),
    ('IFAC',     'C1200', '323', 'direct'),
    ('IFAC',     'C1200', '532', 'direct'),
    ('IFAC',     'C1200', '777', 'direct'),
    ('IFAC',     'C1200', '999', 'direct'),
    # Group 6-7: SC-FAC direct (10)
    ('SC-FAC',   'C800',  '123', 'direct'),
    ('SC-FAC',   'C800',  '323', 'direct'),
    ('SC-FAC',   'C800',  '532', 'direct'),
    ('SC-FAC',   'C800',  '777', 'direct'),
    ('SC-FAC',   'C800',  '999', 'direct'),
    ('SC-FAC',   'C1200', '123', 'direct'),
    ('SC-FAC',   'C1200', '323', 'direct'),
    ('SC-FAC',   'C1200', '532', 'direct'),
    ('SC-FAC',   'C1200', '777', 'direct'),
    ('SC-FAC',   'C1200', '999', 'direct'),
    # Group 8-9: SC-FAC-zero direct (6)
    ('SC-FAC-zero', 'C800',  '123', 'direct'),
    ('SC-FAC-zero', 'C800',  '323', 'direct'),
    ('SC-FAC-zero', 'C800',  '532', 'direct'),
    ('SC-FAC-zero', 'C1200', '123', 'direct'),
    ('SC-FAC-zero', 'C1200', '323', 'direct'),
    ('SC-FAC-zero', 'C1200', '532', 'direct'),
    # Group 10-11: SC-FAC-zero receipt (4)
    ('SC-FAC-zero', 'C800',  '777', 'receipt'),
    ('SC-FAC-zero', 'C800',  '999', 'receipt'),
    ('SC-FAC-zero', 'C1200', '777', 'receipt'),
    ('SC-FAC-zero', 'C1200', '999', 'receipt'),
]

# Map (method, C, seed, res_type) → job_id
METHOD_TO_JID = {
    ('JA-PPO',    'C800',  '123'): 'A-EVAL-JA-C800-S123',
    ('JA-PPO',    'C800',  '323'): 'A-EVAL-JA-C800-S323',
    ('JA-PPO',    'C800',  '532'): 'A-EVAL-JA-C800-S532',
    ('JA-PPO',    'C800',  '777'): 'A-EVAL-JA-C800-S777',
    ('JA-PPO',    'C800',  '999'): 'A-EVAL-JA-C800-S999',
    ('JA-PPO',    'C1200', '123'): 'A-EVAL-JA-C1200-S123',
    ('JA-PPO',    'C1200', '323'): 'A-EVAL-JA-C1200-S323',
    ('JA-PPO',    'C1200', '532'): 'A-EVAL-JA-C1200-S532',
    ('JA-PPO',    'C1200', '777'): 'A-EVAL-JA-C1200-S777',
    ('JA-PPO',    'C1200', '999'): 'A-EVAL-JA-C1200-S999',
    ('IFAC',      'C800',  '123'): 'A-EVAL-IF-C800-S123',
    ('IFAC',      'C800',  '323'): 'A-EVAL-IF-C800-S323',
    ('IFAC',      'C800',  '532'): 'A-EVAL-IF-C800-S532',
    ('IFAC',      'C800',  '777'): 'A-EVAL-IF-C800-S777',
    ('IFAC',      'C800',  '999'): 'A-EVAL-IF-C800-S999',
    ('IFAC',      'C1200', '123'): 'A-EVAL-IF-C1200-S123',
    ('IFAC',      'C1200', '323'): 'A-EVAL-IF-C1200-S323',
    ('IFAC',      'C1200', '532'): 'A-EVAL-IF-C1200-S532',
    ('IFAC',      'C1200', '777'): 'A-EVAL-IF-C1200-S777',
    ('IFAC',      'C1200', '999'): 'A-EVAL-IF-C1200-S999',
    ('SC-FAC',    'C800',  '123'): 'A-EVAL-SC-C800-S123',
    ('SC-FAC',    'C800',  '323'): 'A-EVAL-SC-C800-S323',
    ('SC-FAC',    'C800',  '532'): 'A-EVAL-SC-C800-S532',
    ('SC-FAC',    'C800',  '777'): 'A-EVAL-SC-C800-S777',
    ('SC-FAC',    'C800',  '999'): 'A-EVAL-SC-C800-S999',
    ('SC-FAC',    'C1200', '123'): 'A-EVAL-SC-C1200-S123',
    ('SC-FAC',    'C1200', '323'): 'A-EVAL-SC-C1200-S323',
    ('SC-FAC',    'C1200', '532'): 'A-EVAL-SC-C1200-S532',
    ('SC-FAC',    'C1200', '777'): 'A-EVAL-SC-C1200-S777',
    ('SC-FAC',    'C1200', '999'): 'A-EVAL-SC-C1200-S999',
    ('SC-FAC-zero','C800',  '123'): 'B-EVAL-ZERO-C800-S123',
    ('SC-FAC-zero','C800',  '323'): 'B-EVAL-ZERO-C800-S323',
    ('SC-FAC-zero','C800',  '532'): 'B-EVAL-ZERO-C800-S532',
    ('SC-FAC-zero','C800',  '777'): 'B-EVAL-ZERO-C800-S777',
    ('SC-FAC-zero','C800',  '999'): 'B-EVAL-ZERO-C800-S999',
    ('SC-FAC-zero','C1200', '123'): 'B-EVAL-ZERO-C1200-S123',
    ('SC-FAC-zero','C1200', '323'): 'B-EVAL-ZERO-C1200-S323',
    ('SC-FAC-zero','C1200', '532'): 'B-EVAL-ZERO-C1200-S532',
    ('SC-FAC-zero','C1200', '777'): 'B-EVAL-ZERO-C1200-S777',
    ('SC-FAC-zero','C1200', '999'): 'B-EVAL-ZERO-C1200-S999',
    ('BF-T0.5',   'C800',  'NA'): 'C-EVAL-BFT05-C800',
    ('BF-T0.5',   'C1200', 'NA'): 'C-EVAL-BFT05-C1200',
}

VALIDATION_REPS = {
    'A-EVAL-IF-C800-S123', 'A-EVAL-SC-C800-S123',
    'B-EVAL-ZERO-C800-S123', 'C-EVAL-BFT05-C800',
}

def sha256_file(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def load_job_matrix():
    """Load frozen job matrix, verify SHA, filter to evaluations."""
    sha = sha256_file(JOB_MATRIX)
    jobs = list(csv.DictReader(open(JOB_MATRIX)))
    evals = [j for j in jobs if j['training_required']=='false']
    return evals, sha

def ordered_job_ids():
    """Return list of (job_id, group_desc) in frozen execution order."""
    result = []
    for method, C, seed, restype in EXECUTION_ORDER:
        key = (method, C, seed)
        assert key in METHOD_TO_JID, f"Unknown key: {key}"
        jid = METHOD_TO_JID[key]
        result.append((jid, f"{method} {C} seed={seed} ({restype})"))
    assert len(result) == 42, f"Expected 42, got {len(result)}"
    return result

def load_ledger():
    if LEDGER_PATH.exists():
        return json.loads(LEDGER_PATH.read_text())
    return {'version': 1, 'start_time_utc': None, 'completed': {}, 'failed': {},
            'infra_failed': {}, 'last_updated_utc': None}

def save_ledger(ledger):
    ledger['last_updated_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LEDGER_PATH.write_text(json.dumps(ledger, indent=2, sort_keys=True) + '\n')

def job_is_valid_completed(jid):
    """Check if a job's output dir has valid completed results."""
    out_dir = OUTPUT_DIR/jid
    result_json = out_dir/'result.json'
    episodes_csv = out_dir/'episodes.csv'
    if not (result_json.is_file() and episodes_csv.is_file()):
        return False
    try:
        doc = json.loads(result_json.read_text())
        # Must have passed validation AND correct row count
        if doc.get('validation_status') != 'PASS':
            return False
        if doc.get('row_count') != 2400:
            return False
        # episodes.csv must be non-trivial size
        if episodes_csv.stat().st_size < 10000:
            return False
        return True
    except Exception:
        return False

def run_one_job(jid, job_desc, ledger, retry_infra=False):
    """Run a single job. Returns ('ok', stats), ('skip', reason), ('fail', info), ('infra', info)."""
    out_dir = OUTPUT_DIR/jid
    log_file = LOG_DIR / f"{jid}.log"
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    # Check if already valid
    if job_is_valid_completed(jid):
        return ('skip', 'already validly completed — skipping')

    print(f"\n{'─'*70}")
    print(f"ORCHESTRATOR: {jid}")
    print(f"  desc: {job_desc}")
    print(f"{'─'*70}")

    start_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    start_time = time.time()

    cmd = [sys.executable, str(BENCHMARK_PY), '--job-id', jid, '--benchmark-dir', str(BUNDLE_ROOT)]
    print(f"  cmd:  {' '.join(cmd)}")
    print(f"  log:  {log_file}")
    print(f"  start: {start_utc}")

    try:
        with open(log_file, 'w') as logf:
            logf.write(f"# stage2b_orchestrator job: {jid}\n")
            logf.write(f"# started: {start_utc}\n# cmd: {' '.join(cmd)}\n\n")
            logf.flush()
            proc = subprocess.run(
                cmd, stdout=logf, stderr=subprocess.STDOUT,
                cwd=str(BUNDLE_ROOT), timeout=7200,  # 2h max per job
            )
    except subprocess.TimeoutExpired:
        elapsed = time.time() - start_time
        info = {'type': 'infra_timeout', 'elapsed_s': round(elapsed, 1),
                'note': f'Job exceeded 2h timeout (should be <5 min on Mac)'}
        return ('infra', info)
    except OSError as e:
        elapsed = time.time() - start_time
        info = {'type': 'infra_oserror', 'elapsed_s': round(elapsed, 1),
                'note': str(e)}
        return ('infra', info)

    elapsed = time.time() - start_time

    # Benchmark wrapper checks adapter.Stop internally which raises adapter.Stop.
    # On success, wrapper exits 0. On scientific failure, adapter.Stop is raised and
    # exits non-zero.
    if proc.returncode != 0:
        # Parse log to classify
        log_text = log_file.read_text()
        if 'adapter.Stop' in log_text or 'validation_status' in log_text.lower() or 'FAIL' in log_text:
            info = {'type': 'scientific_failure', 'elapsed_s': round(elapsed, 1),
                    'returncode': proc.returncode,
                    'log_tail': '\n'.join(log_text.splitlines()[-20:])}
            return ('fail', info)
        elif 'Missing' in log_text or 'SHA mismatch' in log_text or 'require' in log_text.lower():
            info = {'type': 'scientific_failure', 'elapsed_s': round(elapsed, 1),
                    'returncode': proc.returncode,
                    'log_tail': '\n'.join(log_text.splitlines()[-20:])}
            return ('fail', info)
        else:
            info = {'type': 'infra_nonzero_exit', 'elapsed_s': round(elapsed, 1),
                    'returncode': proc.returncode,
                    'log_tail': '\n'.join(log_text.splitlines()[-20:])}
            return ('infra', info)

    # Verify outputs
    if not job_is_valid_completed(jid):
        # Non-zero exit from wrapper means benchmark script itself had an issue
        # (which should be infra). But if exit=0 and not valid, treat as scientific failure
        log_text = log_file.read_text()
        info = {'type': 'scientific_failure_no_valid_output',
                'elapsed_s': round(elapsed, 1),
                'returncode': proc.returncode,
                'log_tail': '\n'.join(log_text.splitlines()[-30:])}
        return ('fail', info)

    # Load result for ledger entry
    result_json = json.loads((out_dir/'result.json').read_text())
    episodes_sha = sha256_file(out_dir/'episodes.csv')
    result_sha = sha256_file(out_dir/'result.json')

    stats = {
        'start_utc': start_utc,
        'end_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'elapsed_seconds': round(elapsed, 1),
        'returncode': 0,
        'row_count': result_json['row_count'],
        'macro12_money': result_json['macro12_money'],
        'validation_status': result_json['validation_status'],
        'episodes_sha256': episodes_sha,
        'result_sha256': result_sha,
        'output_dir': str(out_dir),
        'log_file': str(log_file),
        'method': result_json.get('job_method'),
    }
    # Extract method from result if not present
    if not stats['method']:
        # Try to read from job matrix
        evals, _ = load_job_matrix()
        for j in evals:
            if j['job_id'] == jid:
                stats['method'] = j['method']
                break

    return ('ok', stats)


def main():
    ap = argparse.ArgumentParser(description='Stage 2B Mac CPU orchestrator')
    ap.add_argument('--job-id', help='Run only this specific job_id')
    ap.add_argument('--list-only', action='store_true', help='Print ordered job list and exit')
    ap.add_argument('--retry-infra', action='store_true',
                    help='Retry infrastructure-failed jobs (scientific failures still stop)')
    ap.add_argument('--skip-validation-reps', action='store_true',
                    help='Skip the 4 validation-gate reps (already run during gate)')
    ap.add_argument('--continue-on-fail', action='store_true',
                    help='Continue past scientific failures (dangerous — production should stop)')
    args = ap.parse_args()

    # Verify prerequisites
    assert BENCHMARK_PY.is_file(), f"Missing run_benchmark.py at {BENCHMARK_PY}"
    assert JOB_MATRIX.is_file(), f"Missing STAGE2_JOB_MATRIX.csv at {JOB_MATRIX}"
    assert sys.executable, "No python interpreter"

    ledger = load_ledger()
    job_matrix, jm_sha = load_job_matrix()
    ordered = ordered_job_ids()

    if args.list_only:
        print(f"\n{'='*70}")
        print(f"STAGE 2B MAC BATCH — EXECUTION ORDER (42 jobs, frozen)")
        print(f"{'='*70}")
        groups_seen = {}
        prev_method = None
        for i, (jid, desc) in enumerate(ordered):
            method = jid.split('-')[1] if len(jid.split('-')) > 1 else jid
            if method != prev_method:
                print(f"\n  ── {method} ──")
                prev_method = method
            prefix = "  " if jid in VALIDATION_REPS else "   "
            print(f"  {i+1:2d}. {prefix} {jid:30s}  ({desc})")
        print(f"\n  Total: {len(ordered)} evaluation jobs")
        print(f"  ── Validation-rep jobs (4): {', '.join(sorted(VALIDATION_REPS))}")
        print(f"  ── All must be re-run on Mac for parity consistency")
        return 0

    if args.job_id:
        ordered = [(args.job_id, 'single job')]

    # Skip validation reps if requested
    if args.skip_validation_reps and not args.job_id:
        ordered = [(jid, d) for jid, d in ordered if jid not in VALIDATION_REPS]

    # Banner
    if ledger['start_time_utc'] is None:
        ledger['start_time_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    print(f"\n{'#'*70}")
    print(f"STAGE 2B MAC CPU ORCHESTRATOR")
    print(f"{'#'*70}")
    print(f"  Bundle root:  {BUNDLE_ROOT}")
    print(f"  Job matrix:   {JOB_MATRIX}  (SHA {jm_sha[:16]}…)")
    print(f"  Total jobs:   {len(ordered)}")
    print(f"  Resume mode:  automatic (ledger at {LEDGER_PATH})")
    print(f"  Retry infra:  {'yes' if args.retry_infra else 'no'}")
    print(f"  Stop on sci:  {'no (CONTINUE — dangerous)' if args.continue_on_fail else 'yes (DEFAULT)'}")
    print(f"  Start time:   {ledger['start_time_utc']}")
    print(f"{'#'*70}")

    # Progress counters
    total = len(ordered)
    completed_count = 0
    skipped_count = 0
    infra_count = 0
    failed_count = 0

    for idx, (jid, desc) in enumerate(ordered, 1):
        print(f"\n[{idx}/{total}]  {jid}  ({desc})")

        # Already in ledger as completed → skip
        if jid in ledger['completed']:
            if job_is_valid_completed(jid):
                print(f"  ⏭  ALREADY COMPLETED (valid) — SKIP")
                skipped_count += 1
                completed_count += 1
                continue
            else:
                print(f"  ⚠  Ledger says completed but output is INVALID — re-running")
                del ledger['completed'][jid]

        status, info = run_one_job(jid, desc, ledger, args.retry_infra)

        if status == 'ok':
            ledger['completed'][jid] = info
            save_ledger(ledger)
            completed_count += 1
            print(f"  ✅ OK  wall={info['elapsed_seconds']:.1f}s  macro12={info['macro12_money']:.2f}  episodes_sha={info['episodes_sha256'][:16]}…")

        elif status == 'skip':
            completed_count += 1
            skipped_count += 1
            print(f"  ⏭  SKIP ({info})")

        elif status == 'infra':
            ledger['infra_failed'][jid] = info
            save_ledger(ledger)
            infra_count += 1
            print(f"  ⚡ INFRASTRUCTURE FAILURE: {info['type']}  {info.get('note','')}")
            if not args.retry_infra:
                print(f"  └─ Set --retry-infra to retry. Stopping.")
                break
            else:
                print(f"  └─ --retry-infra set — will retry on next orchestrator run")

        elif status == 'fail':
            ledger['failed'][jid] = info
            save_ledger(ledger)
            failed_count += 1
            print(f"  🛑 SCIENTIFIC FAILURE: {info['type']}")
            print(f"     Log tail:")
            for line in info.get('log_tail', '').splitlines()[-15:]:
                print(f"       {line}")
            if not args.continue_on_fail:
                print(f"\n  └─ Production mode: stopping. Review log and run --retry-infra (infra only) or fix scientific issue.")
                break

    # Final summary
    print(f"\n{'#'*70}")
    print(f"ORCHESTRATOR SUMMARY")
    print(f"{'#'*70}")
    print(f"  Total planned:      {total}")
    print(f"  Completed (new):    {len(ledger['completed']) - skipped_count}")
    print(f"  Skipped (already):  {skipped_count}")
    print(f"  Infrastructure:     {infra_count}")
    print(f"  Scientific:         {failed_count}")
    print(f"  Ledger:             {LEDGER_PATH}")
    print(f"  Logs:               {LOG_DIR}")

    if failed_count > 0:
        print(f"\n  ⚠  SCIENTIFIC FAILURE DETECTED — stop. Investigate logs.")
        sys.exit(2)
    elif infra_count > 0:
        print(f"\n  ⚡  INFRASTRUCTURE FAILURE — re-run with --retry-infra")
        sys.exit(3)
    else:
        if len(ledger['completed']) == 42:
            print(f"\n  🎉  STAGE 2B FULL BATCH COMPLETE — all 42 jobs valid")
            print(f"  ✅  MAC_RUNTIME_APPROVED confirmed — full batch from single Mac runtime")
            sys.exit(0)
        else:
            print(f"\n  ⏸  Partial completion: {len(ledger['completed'])}/42 — re-run to resume")
            sys.exit(0)

if __name__ == '__main__':
    main()
