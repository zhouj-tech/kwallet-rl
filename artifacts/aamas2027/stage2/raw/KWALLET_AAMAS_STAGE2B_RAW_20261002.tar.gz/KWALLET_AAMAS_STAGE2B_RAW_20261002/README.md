# K-Wallet AAMAS 2027 — Stage 2B Raw Freeze

Freeze date: 2026-10-02

Contents:
- 42 Stage 2B evaluation outputs
- episode-level scientific outputs
- per-job result metadata and logs
- progress ledger
- MAC_RUNTIME_APPROVED receipt
- frozen Stage 2 job matrix
- NEW12 provenance
- execution scripts and SHA256 manifest

Scientific status:
- 42 evaluation jobs available
- CPU-only Mac official evaluation runtime
- frozen adapter / NEW12 / job matrix
- no principal-policy retraining in Stage 2B

This directory is the immutable raw-results source for subsequent Stage 3 statistical analysis.
